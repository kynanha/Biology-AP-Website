import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Prostate Cancer Guide for Students" },
      {
        name: "description",
        content:
          "A clear, interactive student guide to prostate anatomy, cancer, risk factors, symptoms, and prevention.",
      },
      { property: "og:title", content: "Prostate Cancer Guide for Students" },
      {
        property: "og:description",
        content:
          "Explore prostate anatomy and health with clear explanations, interactive diagrams, and a quiz.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <main className="h-screen overflow-hidden bg-background">
      <iframe
        className="h-full w-full border-0"
        src="/prostate-guide.html"
        title="Interactive prostate cancer guide"
      />
    </main>
  );
}